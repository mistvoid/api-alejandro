const {
  DynamoDBClient,
  PutItemCommand,
  ScanCommand,
  GetItemCommand,
  UpdateItemCommand,
  DeleteItemCommand
} = require("@aws-sdk/client-dynamodb");
const { marshall, unmarshall } = require("@aws-sdk/util-dynamodb");

const client = new DynamoDBClient({});
const TABLE_NAME = process.env.PRODUCTS_TABLE;

const createResponse = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body)
});

// Crear un producto
module.exports.createProduct = async (event) => {
  try {
    const { id, nombre, descripcion, precio } = JSON.parse(event.body);
    const params = {
      TableName: TABLE_NAME,
      Item: marshall({ id, nombre, descripcion, precio })
    };
    await client.send(new PutItemCommand(params));
    return createResponse(201, { message: "Producto creado", productId: id });
  } catch (error) {
    console.error(error);
    return createResponse(500, { error: "No se pudo crear el producto" });
  }
};

// Obtener todos los productos
module.exports.getProducts = async () => {
  try {
    const params = { TableName: TABLE_NAME };
    const { Items } = await client.send(new ScanCommand(params));
    const products = Items.map(item => unmarshall(item));
    return createResponse(200, products);
  } catch (error) {
    console.error(error);
    return createResponse(500, { error: "No se pudo obtener los productos" });
  }
};

// Obtener un producto por ID
module.exports.getProductById = async (event) => {
  try {
    const { id } = event.pathParameters;
    const params = {
      TableName: TABLE_NAME,
      Key: marshall({ id })
    };
    const { Item } = await client.send(new GetItemCommand(params));
    if (!Item) return createResponse(404, { error: "Producto no encontrado" });
    return createResponse(200, unmarshall(Item));
  } catch (error) {
    console.error(error);
    return createResponse(500, { error: "No se pudo obtener el producto" });
  }
};

// Actualizar un producto
module.exports.updateProduct = async (event) => {
  try {
    const { id } = event.pathParameters;
    const { nombre, descripcion, precio } = JSON.parse(event.body);
    const params = {
      TableName: TABLE_NAME,
      Key: marshall({ id }),
      UpdateExpression: "SET nombre = :nombre, descripcion = :descripcion, precio = :precio",
      ExpressionAttributeValues: marshall({
        ":nombre": nombre,
        ":descripcion": descripcion,
        ":precio": precio
      })
    };
    await client.send(new UpdateItemCommand(params));
    return createResponse(200, { message: "Producto actualizado" });
  } catch (error) {
    console.error(error);
    return createResponse(500, { error: "No se pudo actualizar el producto" });
  }
};

// Eliminar un producto
module.exports.deleteProduct = async (event) => {
  try {
    const { id } = event.pathParameters;
    const params = {
      TableName: TABLE_NAME,
      Key: marshall({ id })
    };
    await client.send(new DeleteItemCommand(params));
    return createResponse(200, { message: "Producto eliminado" });
  } catch (error) {
    console.error(error);
    return createResponse(500, { error: "No se pudo eliminar el producto" });
  }
};
